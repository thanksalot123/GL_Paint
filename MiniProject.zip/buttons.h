#include <GL/glut.h>
#include <iostream>

using namespace std;

void Buttons(){
    cout << "Does this even work!";
}
