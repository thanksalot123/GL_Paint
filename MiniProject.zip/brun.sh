#! /bin/bash

g++ -o main mouse_test.cpp -lGL -lGLU -lglut
./main
